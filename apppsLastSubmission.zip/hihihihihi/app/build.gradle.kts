plugins {
    alias(libs.plugins.androidApplication)
    alias(libs.plugins.jetbrainsKotlinAndroid)
    id("com.google.gms.google-services") // Required for Firebase
}

android {
    namespace = "com.example.ibrahim.appp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.ibrahim.appp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        multiDexEnabled = true // Enable MultiDex for apps with many dependencies

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true // Enable vector drawable support
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildFeatures {
        compose = true
        dataBinding = true
        viewBinding = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.2" // Updated to latest version
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}" // Exclude unnecessary resources
        }
    }
}

dependencies {
    // Core libraries
    implementation(libs.androidx.core.ktx) // Updated to latest version
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.multidex)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.recyclerview)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.material)
    implementation("com.github.bumptech.glide:glide:4.15.0")
    implementation(libs.androidx.navigation.ui.ktx) // Latest stable version of Glide
    annotationProcessor("com.github.bumptech.glide:compiler:4.15.0") // For annotation processing
    implementation("com.infobip:google-webrtc:1.0.0035529")

    // Firebase
    implementation(platform(libs.firebase.bom)) // Firebase BOM (manages Firebase versioning)
    implementation(libs.firebase.auth)
    implementation(libs.firebase.database.ktx)

    // Jetpack Compose
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom)) // Compose BOM for compatibility
    implementation(libs.androidx.material3)

    // Navigation
    implementation(libs.androidx.navigation.fragment)

    // Testing
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))

}
