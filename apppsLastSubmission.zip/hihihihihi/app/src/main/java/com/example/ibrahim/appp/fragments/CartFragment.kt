package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ibrahim.appp.adapters.CartAdapter
import com.example.ibrahim.appp.databinding.FragmentCartBinding
import com.example.ibrahim.appp.models.Medication
import com.example.ibrahim.appp.viewmodels.CartViewModel

class CartFragment : Fragment() {

    private var _binding: FragmentCartBinding? = null
    private val binding get() = _binding!!

    private val cartViewModel: CartViewModel by activityViewModels() // Shared ViewModel for cart
    private lateinit var cartAdapter: CartAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCartBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        observeCartViewModel() // Observe changes in the cart
        setupRecyclerView()
        setupButtons()
    }

    private fun observeCartViewModel() {
        // Observe cart items and update RecyclerView
        cartViewModel.cartItems.observe(viewLifecycleOwner) { updatedCartItems ->
            if (updatedCartItems.isEmpty()) {
                showEmptyCartMessage()
            } else {
                hideEmptyCartMessage()
                updateRecyclerView(updatedCartItems)
            }
        }

        // Observe total price and update UI
        cartViewModel.totalPrice.observe(viewLifecycleOwner) { updatedTotalPrice ->
            binding.totalPriceTextView.text = "Total Price: ${String.format("%.2f", updatedTotalPrice)}EGP"
        }
    }

    private fun setupRecyclerView() {
        // Initialize CartAdapter
        cartAdapter = CartAdapter(
            items = mutableListOf(),
            onDecrement = { medication ->
                cartViewModel.updateMedicationQuantity(medication.id, medication.quantity)
            },
            onRemove = { medication ->
                cartViewModel.removeFromCart(medication)
            }
        )

        // Set up RecyclerView
        binding.cartRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = cartAdapter
        }
    }

    private fun updateRecyclerView(cartItems: List<Medication>) {
        cartAdapter.apply {
            this.items.clear()
            this.items.addAll(cartItems)
            notifyDataSetChanged()
        }
    }

    private fun setupButtons() {
        // Handle "Order" button
        binding.orderButton.setOnClickListener {
            orderMedications()
        }

        // Handle "Clear Cart" button
        binding.clearCartButton.setOnClickListener {
            clearCart()
        }
    }

    private fun removeMedicationFromCart(medication: Medication) {
        // Remove medication from cart via ViewModel
        cartViewModel.removeFromCart(medication)

        // Provide feedback
        Toast.makeText(
            requireContext(),
            "${medication.name} removed from the cart",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun showEmptyCartMessage() {
        binding.emptyCartTextView.visibility = View.VISIBLE
        binding.cartRecyclerView.visibility = View.GONE
        binding.totalPriceTextView.visibility = View.GONE
        binding.orderButton.visibility = View.GONE
        binding.clearCartButton.visibility = View.GONE
    }

    private fun hideEmptyCartMessage() {
        binding.emptyCartTextView.visibility = View.GONE
        binding.cartRecyclerView.visibility = View.VISIBLE
        binding.totalPriceTextView.visibility = View.VISIBLE
        binding.orderButton.visibility = View.VISIBLE
        binding.clearCartButton.visibility = View.VISIBLE
    }

    private fun clearCart() {
        // Clear all items in the cart via ViewModel
        cartViewModel.clearCart()

        // Provide feedback
        Toast.makeText(requireContext(), "Cart cleared", Toast.LENGTH_SHORT).show()
    }

    private fun orderMedications() {
        if (cartViewModel.cartItems.value.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Cart is empty! Add items to order.", Toast.LENGTH_SHORT).show()
            return
        }

        // Simulate placing an order (implement backend logic here)
        Toast.makeText(requireContext(), "Order placed for selected medications!", Toast.LENGTH_SHORT).show()

        // Clear the cart after ordering
        clearCart()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
