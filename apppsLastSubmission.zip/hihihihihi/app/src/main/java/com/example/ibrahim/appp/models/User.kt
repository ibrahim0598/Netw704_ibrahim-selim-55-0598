
package com.example.ibrahim.appp.models

data class User(
    val email: String = "",  // Email address of the user
    val role: String = "",   // Role of the user, either "Doctor" or "Patient"
    val uid: String = ""     // Firebase UID of the user
)

