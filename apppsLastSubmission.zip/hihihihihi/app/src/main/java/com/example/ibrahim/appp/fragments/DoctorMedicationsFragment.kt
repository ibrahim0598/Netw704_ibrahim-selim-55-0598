package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.ibrahim.appp.R
import com.example.ibrahim.appp.adapters.DoctorMedicationAdapter
import com.example.ibrahim.appp.databinding.FragmentDoctorMedicationsBinding
import com.example.ibrahim.appp.models.DoctorMedication
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class DoctorMedicationsFragment : Fragment() {

    private var _binding: FragmentDoctorMedicationsBinding? = null
    private val binding get() = _binding!!

    private val medications = mutableListOf<DoctorMedication>() // List of medications
    private lateinit var database: DatabaseReference // Firebase Realtime Database reference
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    private lateinit var adapter: DoctorMedicationAdapter

    private var editingMedication: DoctorMedication? = null  // Store the medication being edited

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDoctorMedicationsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize Firebase Realtime Database with the correct URL
        database =
            FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
                .getReference("medications")

        // Set up RecyclerView
        setupRecyclerView()

        // Fetch medications from Firebase
        fetchMedicationItems()

        // Add medication button logic
        binding.addMedicationButton.setOnClickListener {
            val medicationName = binding.medicationNameEditText.text.toString().trim()
            val medicationPriceText = binding.medicationPriceEditText.text.toString().trim()
            val medicationQuantityText = binding.medicationQuantityEditText.text.toString().trim()

            if (medicationName.isEmpty() || medicationPriceText.isEmpty() || medicationQuantityText.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            }

            val medicationPrice = medicationPriceText.toDoubleOrNull()
            val medicationQuantity = medicationQuantityText.toIntOrNull()

            if (medicationPrice == null || medicationQuantity == null) {
                Toast.makeText(
                    requireContext(),
                    "Please enter valid price and quantity",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val newMedication = DoctorMedication(
                name = medicationName,
                price = medicationPrice,
                quantity = medicationQuantity,
                doctorId = FirebaseAuth.getInstance().currentUser?.uid ?: "",
                imageResId = R.drawable.ic_medication_placeholder // Use the placeholder image by default
            )

            // Add the new medication to Firebase
            addMedicationToFirebase(newMedication)

            // Clear input fields after adding
            binding.medicationNameEditText.text.clear()
            binding.medicationPriceEditText.text.clear()
            binding.medicationQuantityEditText.text.clear()
        }

        // Save edited medication button logic
        binding.saveEditedMedicationButton.setOnClickListener {
            val medicationName = binding.medicationNameEditText.text.toString().trim()
            val medicationPriceText = binding.medicationPriceEditText.text.toString().trim()
            val medicationQuantityText = binding.medicationQuantityEditText.text.toString().trim()

            if (medicationName.isEmpty() || medicationPriceText.isEmpty() || medicationQuantityText.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            }

            val medicationPrice = medicationPriceText.toDoubleOrNull()
            val medicationQuantity = medicationQuantityText.toIntOrNull()

            if (medicationPrice == null || medicationQuantity == null) {
                Toast.makeText(
                    requireContext(),
                    "Please enter valid price and quantity",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val updatedMedication = editingMedication?.copy(
                name = medicationName,
                price = medicationPrice,
                quantity = medicationQuantity,
                updatedAt = System.currentTimeMillis().toString()
            )

            if (updatedMedication != null) {
                editMedicationInFirebase(updatedMedication)
            }
        }
    }

    private fun fetchMedicationItems() {
        // Show loading indicator while fetching the data
        showLoading(true)

        val doctorId = auth.currentUser?.uid
        if (doctorId.isNullOrBlank()) {
            Log.e("DoctorMedicationsFragment", "User is not authenticated.")
            showError("Please log in again.")
            showLoading(false)
            return
        }

        val query: Query = database
            .orderByChild("doctorId")  // Query by doctorId
            .equalTo(doctorId)  // Filter to only the doctor’s medications

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    Log.w(
                        "DoctorMedicationsFragment",
                        "No medications found for doctorId: $doctorId"
                    )
                    showEmptyState(true)
                    showLoading(false)
                    return
                }

                medications.clear()

                // Deserialize medications from Firebase
                for (itemSnapshot in snapshot.children) {
                    val medication = itemSnapshot.getValue(DoctorMedication::class.java)
                    if (medication != null) {
                        medications.add(medication)
                    }
                }

                // Update the RecyclerView
                adapter.notifyDataSetChanged()

                // Update UI visibility
                binding.medicationsRecyclerView.visibility =
                    if (medications.isNotEmpty()) View.VISIBLE else View.GONE
                showEmptyState(medications.isEmpty())
                showLoading(false)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("DoctorMedicationsFragment", "Error fetching medications: ${error.message}")
                showError("Failed to load medications. Please try again.")
                showLoading(false)
            }
        })
    }

    private fun setupRecyclerView() {
        // Create the adapter and handle callbacks
        adapter = DoctorMedicationAdapter(
            medications = medications,
            onAddMedication = { medication ->
                // Handle adding new medication to Firebase
                addMedicationToFirebase(medication)
            },
            onEditMedication = { medication ->
                // Handle editing medication (editing only name, price, and quantity)
                editingMedication = medication
                // Fill the input fields with the medication's current values
                binding.medicationNameEditText.setText(medication.name)
                binding.medicationPriceEditText.setText(medication.price.toString())
                binding.medicationQuantityEditText.setText(medication.quantity.toString())

                // Hide the Add button and show the Save button
                binding.addMedicationButton.visibility = View.GONE
                binding.saveEditedMedicationButton.visibility = View.VISIBLE
            },
            onDeleteMedication = { medication ->
                // Handle deleting medication from Firebase
                deleteMedicationFromFirebase(medication)
            }
        )

        // Set up the RecyclerView with a GridLayoutManager (2 columns)
        binding.medicationsRecyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.medicationsRecyclerView.adapter = adapter
    }

    private fun addMedicationToFirebase(medication: DoctorMedication) {
        val doctorId = auth.currentUser?.uid
        if (doctorId.isNullOrBlank()) {
            showError("Doctor not authenticated")
            return
        }

        // Create a new medication ID
        val medicationId = database.push().key ?: return

        // Set the current time for `createdAt` and `updatedAt`
        val currentTime = System.currentTimeMillis().toString()

        val newMedication = medication.copy(
            id = medicationId,
            doctorId = doctorId,
            createdAt = currentTime,
            updatedAt = currentTime
        )

        // Push the new medication to Firebase
        database.child(medicationId).setValue(newMedication)
            .addOnSuccessListener {
                Toast.makeText(
                    requireContext(),
                    "Medication added successfully",
                    Toast.LENGTH_SHORT
                ).show()
                medications.add(newMedication)  // Add to the list and update UI
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                showError("Failed to add medication")
            }
    }

    private fun editMedicationInFirebase(medication: DoctorMedication) {
        val doctorId = auth.currentUser?.uid
        if (doctorId.isNullOrBlank()) {
            showError("Doctor not authenticated")
            return
        }

        val medicationId = medication.id
        if (medicationId.isNullOrBlank()) {
            showError("Invalid medication ID")
            return
        }

        // Update only relevant fields and set updatedAt
        val updatedMedication = medication.copy(
            name = medication.name,
            quantity = medication.quantity,
            updatedAt = System.currentTimeMillis().toString() // Update the timestamp
        )

        // Update the medication in Firebase
        database.child(medicationId).setValue(updatedMedication)
            .addOnSuccessListener {
                Toast.makeText(
                    requireContext(),
                    "Medication updated successfully",
                    Toast.LENGTH_SHORT
                ).show()
                medications.find { it.id == medicationId }?.apply {
                    name = updatedMedication.name
                    quantity = updatedMedication.quantity
                    updatedAt = updatedMedication.updatedAt // Update the UI list
                }
                adapter.notifyDataSetChanged()

                // Reset the UI to the default state
                binding.addMedicationButton.visibility = View.VISIBLE
                binding.saveEditedMedicationButton.visibility = View.GONE
                binding.medicationNameEditText.text.clear()
                binding.medicationPriceEditText.text.clear()
                binding.medicationQuantityEditText.text.clear()
                editingMedication = null
            }
            .addOnFailureListener {
                showError("Failed to update medication")
            }
    }

    private fun deleteMedicationFromFirebase(medication: DoctorMedication) {
        val medicationId = medication.id
        if (medicationId.isNullOrBlank()) {
            showError("Invalid medication ID")
            return
        }

        // Delete the medication from Firebase
        database.child(medicationId).removeValue()
            .addOnSuccessListener {
                Toast.makeText(
                    requireContext(),
                    "Medication deleted successfully",
                    Toast.LENGTH_SHORT
                ).show()
                medications.remove(medication) // Remove from the list and update UI
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                showError("Failed to delete medication")
            }
    }

    private fun showEmptyState(isEmpty: Boolean) {
        binding.emptyStateText.visibility = if (isEmpty) View.VISIBLE else View.GONE
    }

    private fun showLoading(show: Boolean) {
        binding.loadingSpinner.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
