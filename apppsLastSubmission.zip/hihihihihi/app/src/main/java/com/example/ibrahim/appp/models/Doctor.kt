package com.example.ibrahim.appp.models

// Doctor.kt


data class Doctor(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val specialty: String = ""
)
