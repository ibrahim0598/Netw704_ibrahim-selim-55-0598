package com.example.ibrahim.appp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ibrahim.appp.databinding.ItemMedicationBinding
import com.example.ibrahim.appp.models.Medication

class MedicationAdapter(
    private val medications: MutableList<Medication>,
    private val onApprovalRequest: (Medication) -> Unit,
    private val onAddToCart: (Medication) -> Unit,
    private val isDoctor: Boolean // Determines doctor vs patient behavior
) : RecyclerView.Adapter<MedicationAdapter.MedicationViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicationViewHolder {
        val binding =
            ItemMedicationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MedicationViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MedicationViewHolder, position: Int) {
        val medication = medications[position]
        holder.bind(medication)
    }

    override fun getItemCount(): Int = medications.size

    inner class MedicationViewHolder(private val binding: ItemMedicationBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(medication: Medication) {
            // Set the medication image (using a local resource here)
            binding.medicationImageView.setImageResource(medication.imageResId)

            // Set the medication description (name)
            binding.medicationDescriptionTextView.text = medication.name

            // Update visibility of options based on quantity
            updateOptionsVisibility(medication)

            // Increase quantity button logic
            binding.increaseButton.setOnClickListener {
                medication.quantity++
                updateOptionsVisibility(medication) // Refresh visibility after increase
            }

            // Decrease quantity button logic
            binding.decreaseButton.setOnClickListener {
                if (medication.quantity > 0) {
                    medication.quantity--
                    updateOptionsVisibility(medication) // Refresh visibility after decrease
                }
            }

            // Handle action button logic dynamically based on role and medication approval status
            binding.actionButton.setOnClickListener {
                if (isDoctor) {
                    // Doctor's workflow: can approve or add directly to the cart
                    if (medication.isApprovalRequired) {
                        onApprovalRequest(medication) // Approve the medication
                    } else {
                        // Add to cart if no approval is required
                        onAddToCart(medication)
                    }
                } else {
                    // Patient's workflow: add to cart regardless of approval status
                    onAddToCart(medication)
                }
            }
        }

        private fun updateOptionsVisibility(medication: Medication) {
            // Show options if quantity > 0, otherwise hide them
            binding.optionsContainer.visibility =
                if (medication.quantity > 0) View.VISIBLE else View.GONE

            // Update price based on quantity
            binding.medicationPriceTextView.text =
                "Price: ${String.format("%.2f", medication.price * medication.quantity)} EGP"

            // Set the action button text based on approval status and role
            binding.actionButton.text = when {
                // Doctor can approve medications
                isDoctor -> {
                    if (medication.isApprovalRequired) {
                        "Approve Medication" // Only show "Approve Medication" if approval is required
                    } else {
                        "Add to Cart" // If no approval is required, show "Add to Cart"
                    }
                }
                // Patient's logic: handle adding to cart directly, bypassing approval
                else -> {
                    "Add to Cart" // Always show "Add to Cart" for patients, even if approval is required
                }
            }

            // Update the displayed quantity
            binding.quantityTextView.text = medication.quantity.toString()
        }
    }
}

