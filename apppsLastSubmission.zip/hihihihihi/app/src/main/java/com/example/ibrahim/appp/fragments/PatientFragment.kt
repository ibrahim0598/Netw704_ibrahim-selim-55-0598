package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.ibrahim.appp.adapters.MedicationAdapter
import com.example.ibrahim.appp.databinding.FragmentPatientBinding
import com.example.ibrahim.appp.models.Medication
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class PatientFragment : Fragment() {

    private var _binding: FragmentPatientBinding? = null
    private val binding get() = _binding!!

    private lateinit var database: DatabaseReference
    private val medications = mutableListOf<Medication>() // Use a MutableList for the adapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPatientBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        database = FirebaseDatabase.getInstance().reference.child("medications")

        val medicationAdapter = MedicationAdapter(
            medications = medications,
            onApprovalRequest = { medication ->
                // Handle medication approval request
                Toast.makeText(requireContext(), "Approval requested for: ${medication.name}", Toast.LENGTH_SHORT).show()
            },
            onAddToCart = { medication ->
                // Handle adding medication to cart
                Toast.makeText(requireContext(), "Added to cart: ${medication.name}", Toast.LENGTH_SHORT).show()
            },
            isDoctor = false // Set to false for PatientFragment
        )

        binding.medicationRecyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.medicationRecyclerView.adapter = medicationAdapter

        loadMedications(medicationAdapter)
    }

    private fun loadMedications(adapter: MedicationAdapter) {
        database.get().addOnSuccessListener { snapshot ->
            medications.clear()
            snapshot.children.mapNotNullTo(medications) {
                it.getValue(Medication::class.java)
            }
            adapter.notifyDataSetChanged()
        }.addOnFailureListener {
            Toast.makeText(requireContext(), "Failed to load medications", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
