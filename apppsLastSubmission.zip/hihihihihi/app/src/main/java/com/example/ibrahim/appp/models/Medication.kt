package com.example.ibrahim.appp.models

import com.example.ibrahim.appp.R

data class Medication(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val price: Double = 0.0,
    var quantity: Int = 0, // Mutable because quantities can change
    var isApproved: Boolean = false, // Changed to var to allow updates
    val isApprovalRequired: Boolean = true, // Immutable, set during initialization
    val imageResId: Int = R.drawable.ic_medication_placeholder // Default placeholder image
)