package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ibrahim.appp.models.ConsultationRequest
import com.example.ibrahim.appp.adapters.ConsultationAdapter
import com.example.ibrahim.appp.databinding.FragmentConsultationBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ConsultationFragment : Fragment() {

    private var _binding: FragmentConsultationBinding? = null
    private val binding get() = _binding!!

    private lateinit var consultationAdapter: ConsultationAdapter
    private val consultations = mutableListOf<ConsultationRequest>()

    private val userId: String by lazy { FirebaseAuth.getInstance().currentUser?.uid.orEmpty() }
    private val database: DatabaseReference by lazy {
        FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .reference.child("consultations").child(userId)
    }
    private val doctorDatabase: DatabaseReference by lazy {
        FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .reference.child("doctorConsultations")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentConsultationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()

        // Load consultations from Firebase
        if (userId.isNotEmpty()) {
            loadConsultationsFromFirebase()
        } else {
            Toast.makeText(requireContext(), "User not authenticated!", Toast.LENGTH_SHORT).show()
        }

        // Handle consultation request button click
        binding.requestConsultationButton.setOnClickListener {
            requestConsultation()
        }
    }

    private fun setupRecyclerView() {
        consultationAdapter = ConsultationAdapter(consultations) { consultation ->
            Toast.makeText(requireContext(), "Selected: ${consultation.id}", Toast.LENGTH_SHORT).show()
        }

        binding.consultationRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = consultationAdapter
        }
    }

    private fun loadConsultationsFromFirebase() {
        binding.progressBar.visibility = View.VISIBLE // Show loading indicator
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                consultations.clear() // Clear existing data
                snapshot.children.mapNotNullTo(consultations) {
                    it.getValue(ConsultationRequest::class.java)
                }
                consultationAdapter.notifyDataSetChanged() // Refresh RecyclerView
                binding.progressBar.visibility = View.GONE // Hide loading indicator
                Log.d("ConsultationFragment", "Loaded ${consultations.size} consultations.")
            }

            override fun onCancelled(error: DatabaseError) {
                binding.progressBar.visibility = View.GONE // Hide loading indicator
                Toast.makeText(
                    requireContext(),
                    "Failed to load consultations: ${error.message}",
                    Toast.LENGTH_SHORT
                ).show()
                Log.e("ConsultationFragment", "Database error: ${error.message}", error.toException())
            }
        })
    }

    private fun requestConsultation() {
        if (userId.isEmpty()) {
            Toast.makeText(requireContext(), "User not authenticated!", Toast.LENGTH_SHORT).show()
            return
        }

        val consultationId = database.push().key ?: return
        val assignedDoctorId = "doctorId1" // Replace with dynamic doctor assignment logic

        val newConsultation = ConsultationRequest(
            id = consultationId,
            status = "Pending",
            response = "",
            date = System.currentTimeMillis().toString() // Timestamp or formatted date
        )

        binding.requestConsultationButton.isEnabled = false // Disable button temporarily
        binding.progressBar.visibility = View.VISIBLE // Show loading indicator

        // Save to patient's consultations node
        database.child(consultationId).setValue(newConsultation)
            .addOnSuccessListener {
                Log.d("ConsultationFragment", "Consultation added to patient's node.")
                saveToDoctorNode(assignedDoctorId, consultationId, newConsultation)
            }
            .addOnFailureListener {
                Toast.makeText(context, "Failed to request consultation", Toast.LENGTH_SHORT).show()
                Log.e("ConsultationFragment", "Failed to save consultation to patient node: ${it.message}")
                binding.requestConsultationButton.isEnabled = true
                binding.progressBar.visibility = View.GONE
            }
    }

    private fun saveToDoctorNode(doctorId: String, consultationId: String, consultation: ConsultationRequest) {
        doctorDatabase.child(doctorId).child(consultationId).setValue(consultation)
            .addOnSuccessListener {
                Toast.makeText(context, "Consultation sent to doctor", Toast.LENGTH_SHORT).show()
                Log.d("ConsultationFragment", "Consultation added to doctor's node.")
                consultations.add(consultation) // Add to local list
                consultationAdapter.notifyItemInserted(consultations.size - 1)
                binding.consultationRecyclerView.scrollToPosition(consultations.size - 1)
            }
            .addOnFailureListener {
                Toast.makeText(context, "Failed to notify doctor", Toast.LENGTH_SHORT).show()
                Log.e("ConsultationFragment", "Failed to save consultation to doctor node: ${it.message}")
            }
            .addOnCompleteListener {
                binding.requestConsultationButton.isEnabled = true
                binding.progressBar.visibility = View.GONE
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
