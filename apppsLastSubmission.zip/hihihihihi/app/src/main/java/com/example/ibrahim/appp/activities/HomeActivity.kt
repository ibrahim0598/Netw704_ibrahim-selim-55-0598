package com.example.ibrahim.appp.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import com.example.ibrahim.appp.R
import com.example.ibrahim.appp.fragments.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {

    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var toolbar: Toolbar
    private var userType: String = "Patient" // Default to "Patient"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Initialize views
        bottomNavigationView = findViewById(R.id.bottom_navigation)
        toolbar = findViewById(R.id.toolbar)

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Get user type from Intent and log it
        userType = intent.getStringExtra("USER_TYPE") ?: "Patient"
        Log.d("HomeActivity", "User type is: $userType")

        // Adjust menu visibility based on user type (Doctor vs Patient)
        adjustMenuVisibility(userType)

        // Load the initial fragment based on user type
        if (userType == "Doctor") {
            loadFragment(DoctorMedicationsFragment())
        } else {
            loadFragment(PatientMedicationsFragment())
        }

        // Handle bottom navigation item selection
        bottomNavigationView.setOnItemSelectedListener { item ->
            val fragment: Fragment? = getFragmentForMenuItem(item.itemId)

            fragment?.let {
                loadFragment(it)
                true
            } ?: false
        }
    }

    // Handle the navigation up (Sign out the user)
    override fun onSupportNavigateUp(): Boolean {
        signOutUser() // Sign out the user
        return true
    }

    private fun signOutUser() {
        // Sign out the user from Firebase
        FirebaseAuth.getInstance().signOut()

        // Log out the user and navigate to LoginActivity
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish() // Close HomeActivity
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    private fun adjustMenuVisibility(userType: String) {
        // Update visibility of menu items based on user type (Doctor or Patient)
        if (userType == "Doctor") {
            bottomNavigationView.menu.findItem(R.id.nav_cart).isVisible = false
            bottomNavigationView.menu.findItem(R.id.nav_consultation).isVisible = false
            bottomNavigationView.menu.findItem(R.id.nav_review).isVisible = true
            bottomNavigationView.menu.findItem(R.id.nav_voip).isVisible = true
        } else {
            bottomNavigationView.menu.findItem(R.id.nav_review).isVisible = false
            bottomNavigationView.menu.findItem(R.id.nav_cart).isVisible = true
            bottomNavigationView.menu.findItem(R.id.nav_consultation).isVisible = true
            bottomNavigationView.menu.findItem(R.id.nav_voip).isVisible = true // Show VoIP for patients
        }
    }

    private fun getFragmentForMenuItem(menuItemId: Int): Fragment? {
        return when (menuItemId) {
            R.id.nav_medications -> if (userType == "Doctor") DoctorMedicationsFragment() else PatientMedicationsFragment()
            R.id.nav_cart -> if (userType != "Doctor") CartFragment() else null
            R.id.nav_consultation -> if (userType != "Doctor") ConsultationFragment() else null
            R.id.nav_review -> if (userType == "Doctor") ReviewFragment() else null
            R.id.nav_voip -> if (userType != "Doctor") VoIPCallFragment() else DoctorVoIPFragment() // Handle navigation to the VoIP fragment

            else -> null
        }
    }
}
