package com.example.ibrahim.appp.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.ibrahim.appp.databinding.ActivityMainBinding
import com.example.ibrahim.appp.viewmodels.CartViewModel

import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var auth: FirebaseAuth
    private val cartViewModel: CartViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

            auth = FirebaseAuth.getInstance()


        // Check if user is signed in

            // User is not signed in, navigate to login/registration activity
            startActivity(Intent(this, LoginActivity::class.java))
            finish()

            // User is signed in, proceed to main application flow
            // ... (Navigation setup, data initialization, etc.)
        }
    }
