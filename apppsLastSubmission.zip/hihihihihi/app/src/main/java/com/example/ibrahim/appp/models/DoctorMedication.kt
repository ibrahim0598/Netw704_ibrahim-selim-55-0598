package com.example.ibrahim.appp.models

import com.example.ibrahim.appp.R

data class DoctorMedication(
    val id: String = "",
    var name: String = "",
    val price: Double = 0.0,
    var quantity: Int = 0,
    val doctorId: String = "",
    val imageResId: Int = R.drawable.ic_medication_placeholder, // Default placeholder image

    // Adding missing fields
    var isApprovalRequired: Boolean = false,
    var createdAt: String = null.toString(),

    var description: String = "",
    var isApproved: Boolean = false,
    var updatedAt: String = null.toString()
)
