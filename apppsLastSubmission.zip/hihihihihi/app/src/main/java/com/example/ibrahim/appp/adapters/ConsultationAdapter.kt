package com.example.ibrahim.appp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ibrahim.appp.databinding.ItemConsultationBinding
import com.example.ibrahim.appp.models.ConsultationRequest

class ConsultationAdapter(
    private val consultations: MutableList<ConsultationRequest>, // List of consultations
    private val onItemClicked: (ConsultationRequest) -> Unit // Callback for item clicks
) : RecyclerView.Adapter<ConsultationAdapter.ConsultationViewHolder>() {

    // Create a ViewHolder that holds the binding for each consultation item
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ConsultationViewHolder {
        val binding = ItemConsultationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ConsultationViewHolder(binding)
    }

    // Bind the data to the views for each item in the RecyclerView
    override fun onBindViewHolder(holder: ConsultationViewHolder, position: Int) {
        val consultation = consultations[position]
        holder.bind(consultation)
    }

    // Get the total number of items in the list
    override fun getItemCount() = consultations.size

    // Update the list of consultations and notify the RecyclerView
    fun updateData(newConsultations: List<ConsultationRequest>) {
        consultations.clear()
        consultations.addAll(newConsultations)
        notifyDataSetChanged()
    }

    inner class ConsultationViewHolder(private val binding: ItemConsultationBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(consultation: ConsultationRequest) {
            // Display consultation details
            binding.consultationStatusTextView.text = "Status: ${consultation.status}"
            binding.consultationResponseTextView.text = "Response: ${consultation.response ?: "No response yet"}"
            binding.consultationDateTextView.text = "Date: ${consultation.date}"

            // Change status appearance based on the consultation status
            when (consultation.status) {
                "Pending" -> {
                    binding.consultationStatusTextView.setTextColor(binding.root.context.getColor(android.R.color.holo_orange_light))
                }
                "Completed" -> {
                    binding.consultationStatusTextView.setTextColor(binding.root.context.getColor(android.R.color.holo_green_light))
                }
                else -> {
                    binding.consultationStatusTextView.setTextColor(binding.root.context.getColor(android.R.color.darker_gray))
                }
            }

            // Handle item click for additional actions (like opening details or updating)
            binding.root.setOnClickListener {
                onItemClicked(consultation)
            }
        }
    }
}
