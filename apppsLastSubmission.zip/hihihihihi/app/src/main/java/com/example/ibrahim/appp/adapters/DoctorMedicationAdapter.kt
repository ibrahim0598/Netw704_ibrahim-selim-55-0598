package com.example.ibrahim.appp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ibrahim.appp.R
import com.example.ibrahim.appp.models.DoctorMedication

class DoctorMedicationAdapter(
    private val medications: List<DoctorMedication>,
    private val onAddMedication: (DoctorMedication) -> Unit,
    private val onEditMedication: (DoctorMedication) -> Unit,
    private val onDeleteMedication: (DoctorMedication) -> Unit
) : RecyclerView.Adapter<DoctorMedicationAdapter.MedicationViewHolder>() {

    // ViewHolder to bind data to the views
    inner class MedicationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val medicationName: TextView = itemView.findViewById(R.id.medicationName)
        val medicationPrice: TextView = itemView.findViewById(R.id.medicationPrice)
        val medicationQuantity: TextView = itemView.findViewById(R.id.medicationQuantity)
        val addButton: Button = itemView.findViewById(R.id.addButton)
        val editButton: Button = itemView.findViewById(R.id.editButton)
        val deleteButton: Button = itemView.findViewById(R.id.deleteButton)

        fun bind(medication: DoctorMedication) {
            medicationName.text = medication.name
            medicationPrice.text = "Price: ${medication.price} EGP"
            medicationQuantity.text = "Quantity: ${medication.quantity}"

            // Add Medication Button
            addButton.setOnClickListener {
                onAddMedication(medication)
            }

            // Edit Medication Button (only edits name and quantity)
            editButton.setOnClickListener {
                onEditMedication(medication)
            }

            // Delete Medication Button
            deleteButton.setOnClickListener {
                onDeleteMedication(medication)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicationViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_doctor_medication, parent, false)
        return MedicationViewHolder(view)
    }

    override fun onBindViewHolder(holder: MedicationViewHolder, position: Int) {
        val medication = medications[position]
        holder.bind(medication)
    }

    override fun getItemCount(): Int = medications.size
}
