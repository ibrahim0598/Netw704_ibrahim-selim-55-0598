package com.example.ibrahim.appp.activities

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ibrahim.appp.databinding.ActivityRegisterBinding
import com.example.ibrahim.appp.models.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // Initialize Firebase Realtime Database with custom URL
        database = FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .getReference("users")

        // User type selection: Doctor or Patient
        val userTypeOptions = arrayOf("Doctor", "Patient")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, userTypeOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.userTypeSpinner.adapter = adapter

        // Register button click listener
        binding.registerButton.setOnClickListener {
            val email = binding.emailEditText.text.toString().trim()
            val password = binding.passwordEditText.text.toString().trim()
            val selectedUserType = binding.userTypeSpinner.selectedItem.toString()

            // Validate input fields
            if (email.isNotEmpty() && password.isNotEmpty()) {
                // Create a user with Firebase Authentication
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            val userId = auth.currentUser?.uid
                            if (userId != null) {
                                // Create a User object to store in the Firebase Realtime Database
                                val user = User(email = email, role = selectedUserType, uid = userId)

                                // Store user data in Firebase Realtime Database
                                database.child(userId).setValue(user).addOnCompleteListener { roleTask ->
                                    if (roleTask.isSuccessful) {
                                        // Successfully stored role, navigate to the login screen
                                        Toast.makeText(baseContext, "Registration Successful", Toast.LENGTH_SHORT).show()

                                        // Redirect to LoginActivity after successful registration
                                        val intent = Intent(this, LoginActivity::class.java)
                                        startActivity(intent)
                                        finish() // Close the register activity
                                    } else {
                                        Toast.makeText(baseContext, "Failed to store user data", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            } else {
                                Toast.makeText(baseContext, "Failed to get user ID", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(baseContext, "Authentication failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
            } else {
                Toast.makeText(baseContext, "Please enter both email and password", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
