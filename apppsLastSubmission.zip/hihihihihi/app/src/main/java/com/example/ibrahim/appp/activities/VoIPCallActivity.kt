package com.example.ibrahim.appp.activities

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.webrtc.*
import com.example.ibrahim.appp.R
import com.google.firebase.database.*

class VoIPCallActivity : AppCompatActivity() {

    private lateinit var ipAddressEditText: EditText
    private lateinit var portNumberEditText: EditText
    private lateinit var connectButton: Button
    private lateinit var endCallButton: Button
    private lateinit var statusTextView: TextView

    private lateinit var peerConnectionFactory: PeerConnectionFactory
    private lateinit var peerConnection: PeerConnection

    private lateinit var videoSource: VideoSource // Declare as lateinit
    private lateinit var videoTrack: VideoTrack  // Declare as lateinit
    private lateinit var audioTrack: AudioTrack  // Declare as lateinit

    private lateinit var remoteRenderer: SurfaceViewRenderer
    private lateinit var database: FirebaseDatabase
    private lateinit var callRef: DatabaseReference

    private var callId: String = "call1"  // Example call ID, you can dynamically generate this or pass it

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voip_call)
        database = FirebaseDatabase.getInstance()

        ipAddressEditText = findViewById(R.id.ip_address)
        portNumberEditText = findViewById(R.id.port_number)
        connectButton = findViewById(R.id.connect_button)
        endCallButton = findViewById(R.id.end_call_button)
        statusTextView = findViewById(R.id.status_text)

        // Initialize WebRTC components
        initializeWebRTC()

        connectButton.setOnClickListener {
            onConnectButtonClick()
        }

        endCallButton.setOnClickListener {
            onEndCallButtonClick()
        }
    }

    private fun initializeWebRTC() {
        // Initialize PeerConnectionFactory
        val options = PeerConnectionFactory.InitializationOptions.builder(this)
            .createInitializationOptions()
        PeerConnectionFactory.initialize(options)

        peerConnectionFactory = PeerConnectionFactory.builder().createPeerConnectionFactory()

        // Create VideoSource and VideoTrack
        val videoCapturer = createCameraCapturer()
        videoSource = peerConnectionFactory.createVideoSource(videoCapturer?.isScreencast ?: false)
        videoTrack = peerConnectionFactory.createVideoTrack("videoTrack", videoSource)

        // Create AudioTrack
        val audioSource = peerConnectionFactory.createAudioSource(MediaConstraints())
        audioTrack = peerConnectionFactory.createAudioTrack("audioTrack", audioSource)

        statusTextView.text = "Ready to Connect"
    }

    private fun createCameraCapturer(): VideoCapturer? {
        val cameraEnumerator = Camera2Enumerator(this)
        val deviceNames = cameraEnumerator.deviceNames
        for (deviceName in deviceNames) {
            if (cameraEnumerator.isFrontFacing(deviceName)) {
                return cameraEnumerator.createCapturer(deviceName, null)
            }
        }
        return null // Default to back camera if front is unavailable
    }

    fun onConnectButtonClick() {

        val ipAddress = ipAddressEditText.text.toString().trim()
        val port = portNumberEditText.text.toString().trim()

        if (ipAddress.isEmpty() || port.isEmpty()) {
            Toast.makeText(this, "Please enter IP and Port", Toast.LENGTH_SHORT).show()
            return
        }

        statusTextView.text = "Connecting..."

        // Create the connection to the IP address and port
        val rtcConfig = PeerConnection.RTCConfiguration(listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()  // Example ICE server
        ))
        statusTextView.text = "building..."
        // Set to UNIFIED_PLAN to support better compatibility for handling video and audio tracks.
        rtcConfig.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN

        // Create the peer connection
        peerConnection = (peerConnectionFactory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {
                Log.d("VoIPCallActivity", "Signaling state changed: $state")
            }

            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate?.let {
                    Log.d("VoIPCallActivity", "Received ICE Candidate: $it")
                    sendIceCandidate(candidate)
                }
            }

            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {
                TODO("Not yet implemented")
            }

            override fun onDataChannel(dataChannel: DataChannel?) {
                Log.d("VoIPCallActivity", "Data channel opened: $dataChannel")
            }

            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                Log.d("VoIPCallActivity", "ICE connection state changed: $newState")
            }

            override fun onIceConnectionReceivingChange(p0: Boolean) {
                TODO("Not yet implemented")
            }

            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {
                Log.d("VoIPCallActivity", "ICE gathering state changed: $newState")
            }

            override fun onAddStream(mediaStream: MediaStream?) {
                Log.d("VoIPCallActivity", "Remote media stream added: $mediaStream")
                mediaStream?.videoTracks?.get(0)?.addSink(remoteRenderer)  // Render remote video
            }

            override fun onRemoveStream(mediaStream: MediaStream?) {
                Log.d("VoIPCallActivity", "Remote media stream removed: $mediaStream")
            }

            override fun onRenegotiationNeeded() {
                Log.d("VoIPCallActivity", "Renegotiation needed, handle re-offer.")
            }
        }) ?: run {
            Log.e("VoIPCallActivity", "PeerConnection creation failed.")
        }) as PeerConnection

        // Add video and audio tracks
        peerConnection.addTrack(videoTrack)
        peerConnection.addTrack(audioTrack)

        // Firebase: Create or get the call node
        callRef = database.reference.child("calls").child(callId)

        // Create the offer and send it
        createOffer()
        endCallButton.visibility = View.VISIBLE
    }

    private fun createOffer() {
        val sdpConstraints = MediaConstraints()
        peerConnection.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                Log.d("VoIPCallActivity", "Offer created successfully")
                sdp?.let {
                    peerConnection.setLocalDescription(object : SdpObserver {
                        override fun onCreateSuccess(sdp: SessionDescription?) {
                            // Send the offer to Firebase under the 'offer' node
                            val offerData = sdp?.description?.let { description ->
                                hashMapOf(
                                    "sdp" to description,
                                    "type" to "offer",
                                    "from" to "RrzgQz9ipiQRzCJR0L5OZE7nlTY2",
                                    "to" to "dkdwJrXMooY56lZIraBiAH1vVm13"
                                )
                            }

                            callRef.child("offer").setValue(offerData)
                        }

                        override fun onSetSuccess() {}
                        override fun onCreateFailure(error: String?) {
                            Log.e("VoIPCallActivity", "Failed to set local description")
                        }

                        override fun onSetFailure(error: String?) {}
                    }, it)
                }
            }

            override fun onCreateFailure(error: String?) {
                Log.e("VoIPCallActivity", "Failed to create offer: $error")
            }

            override fun onSetSuccess() {}
            override fun onSetFailure(error: String?) {}
        }, sdpConstraints)
    }

    private fun sendIceCandidate(candidate: IceCandidate) {
        val iceCandidateData = hashMapOf(
            "candidate" to candidate.sdp,
            "sdpMid" to candidate.sdpMid,
            "sdpMLineIndex" to candidate.sdpMLineIndex
        )
        callRef.child("candidates").push().setValue(iceCandidateData)
    }

    fun onEndCallButtonClick() {
        // Close the call, release resources
        peerConnection.close()
        statusTextView.text = "Call Ended"
        endCallButton.visibility = View.GONE

        // Optionally, send an "end call" signal to Firebase
        callRef.child("status").setValue("ended")
    }

    override fun onDestroy() {
        super.onDestroy()
        peerConnectionFactory.dispose() // Clean up WebRTC resources
    }
}
