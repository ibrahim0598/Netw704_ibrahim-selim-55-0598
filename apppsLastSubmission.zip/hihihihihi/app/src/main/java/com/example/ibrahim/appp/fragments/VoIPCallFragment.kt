package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.ibrahim.appp.databinding.FragmentDoctorVoipBinding
import com.example.ibrahim.appp.databinding.FragmentVoipCallBinding
import com.google.firebase.database.*
import org.webrtc.*

class VoIPCallFragment : Fragment() {

    private lateinit var binding: FragmentVoipCallBinding
    private lateinit var peerConnectionFactory: PeerConnectionFactory
    private var peerConnection: PeerConnection? = null
    private lateinit var audioTrack: AudioTrack
    private lateinit var database: FirebaseDatabase
    private lateinit var callRef: DatabaseReference
    private var callId: String = "call1"  // Example call ID

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentVoipCallBinding.inflate(inflater, container, false)
        database =
            FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
        callRef = database.reference.child("calls").child(callId)

        initializeWebRTC()

        // Set up listeners for buttons
        binding.connectButton.setOnClickListener {
            Log.d("DoctorVoIPFragment", "Connect button clicked")
            onConnectButtonClick()
        }

        binding.endCallButton.setOnClickListener {
            Log.d("DoctorVoIPFragment", "End call button clicked")
            onEndCallButtonClick()
        }

        return binding.root
    }

    private fun onConnectButtonClick() {
        val ipAddress = binding.ipAddress.text.toString().trim()
        val port = binding.portNumber.text.toString().trim()

        if (ipAddress.isEmpty() || port.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter IP and Port", Toast.LENGTH_SHORT).show()
            return
        }

        binding.statusText.text = "Connecting..."

        val rtcConfig = PeerConnection.RTCConfiguration(
            listOf(
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
            )
        )
        rtcConfig.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN

        peerConnection =
            peerConnectionFactory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
                override fun onSignalingChange(state: PeerConnection.SignalingState?) {
                    Log.d("DoctorVoIPFragment", "Signaling state changed: $state")
                }

                override fun onIceCandidate(candidate: IceCandidate?) {
                    candidate?.let {
                        Log.d("DoctorVoIPFragment", "Received ICE Candidate: $it")
                        sendIceCandidate(candidate)
                    }
                }

                override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                    Log.d("DoctorVoIPFragment", "ICE connection state changed: $newState")
                }

                override fun onAddStream(stream: MediaStream?) {
                    Log.d("DoctorVoIPFragment", "Media Stream added: $stream")
                }

                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
                override fun onDataChannel(dataChannel: DataChannel?) {}
                override fun onIceConnectionReceivingChange(receiving: Boolean) {}
                override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {}
                override fun onRemoveStream(stream: MediaStream?) {}
                override fun onRenegotiationNeeded() {}
            })

        peerConnection?.addTrack(audioTrack)
        createOffer()
        listenForIncomingIceCandidates()
        binding.endCallButton.visibility = View.VISIBLE
    }

    private fun createOffer() {
        val sdpConstraints = MediaConstraints()
        peerConnection?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                sdp?.let {
                    peerConnection?.setLocalDescription(object : SdpObserver {
                        override fun onSetSuccess() {
                            val offerData = hashMapOf(
                                "sdp" to it.description,
                                "type" to "offer"
                            )
                            callRef.child("offer").setValue(offerData)
                        }

                        override fun onSetFailure(error: String?) {
                            Log.e("DoctorVoIPFragment", "Failed to set local description: $error")
                        }

                        override fun onCreateSuccess(sdp: SessionDescription?) {}
                        override fun onCreateFailure(error: String?) {}
                    }, it)
                }
            }

            override fun onCreateFailure(error: String?) {
                Log.e("DoctorVoIPFragment", "Failed to create offer: $error")
            }

            override fun onSetSuccess() {}
            override fun onSetFailure(error: String?) {}
        }, sdpConstraints)
    }

    private fun sendIceCandidate(candidate: IceCandidate) {
        val iceCandidateData = hashMapOf(
            "candidate" to candidate.sdp,
            "sdpMid" to candidate.sdpMid,
            "sdpMLineIndex" to candidate.sdpMLineIndex
        )
        callRef.child("candidates").push().setValue(iceCandidateData)
    }

    private fun listenForIncomingIceCandidates() {
        callRef.child("candidates").addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val candidateMap = snapshot.value as? Map<*, *>
                if (candidateMap != null) {
                    val candidate = IceCandidate(
                        candidateMap["sdpMid"] as String,
                        (candidateMap["sdpMLineIndex"] as Long).toInt(),
                        candidateMap["candidate"] as String
                    )
                    peerConnection?.addIceCandidate(candidate)
                    Log.d("DoctorVoIPFragment", "Received and added ICE Candidate: $candidate")
                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {
                Log.e("DoctorVoIPFragment", "Listening for ICE candidates failed: ${error.message}")
            }
        })
    }

    private fun onEndCallButtonClick() {
        peerConnection?.close()
        binding.statusText.text = "Call Ended"
        binding.endCallButton.visibility = View.GONE
        callRef.child("status").setValue("ended")
    }

    override fun onDestroy() {
        super.onDestroy()
        peerConnection?.dispose()
        peerConnectionFactory.dispose()
    }

    private fun initializeWebRTC() {
        val options = PeerConnectionFactory.InitializationOptions.builder(requireContext())
            .createInitializationOptions()
        PeerConnectionFactory.initialize(options)

        peerConnectionFactory = PeerConnectionFactory.builder().createPeerConnectionFactory()

        val audioSource = peerConnectionFactory.createAudioSource(MediaConstraints())
        audioTrack = peerConnectionFactory.createAudioTrack("audioTrack", audioSource)
    }
}