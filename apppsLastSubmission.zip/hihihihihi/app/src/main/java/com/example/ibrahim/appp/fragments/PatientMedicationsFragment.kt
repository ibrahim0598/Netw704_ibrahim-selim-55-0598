package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.example.ibrahim.appp.adapters.MedicationAdapter
import com.example.ibrahim.appp.databinding.FragmentPatientMedicationsBinding
import com.example.ibrahim.appp.models.Medication
import com.example.ibrahim.appp.viewmodels.CartViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class PatientMedicationsFragment : Fragment() {

    private var _binding: FragmentPatientMedicationsBinding? = null
    private val binding get() = _binding!!
    private val medications = mutableListOf<Medication>() // List of medications
    private val cartViewModel: CartViewModel by activityViewModels() // Shared ViewModel for cart
    private lateinit var database: DatabaseReference // Firebase Realtime Database reference
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private lateinit var adapter: MedicationAdapter
    private var medicationListener: ChildEventListener? = null // Store reference to the listener

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPatientMedicationsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize Firebase Realtime Database
        database = FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .reference.child("medications")

        // Set up RecyclerView
        setupRecyclerView()

        // Fetch medications from Firebase
        fetchMedicationItems()
    }

    private fun fetchMedicationItems() {
        showLoading(true)

        // Ensure the user is signed in before performing the query
        val currentUser = auth.currentUser
        if (currentUser == null) {
            showError("You need to sign in to view medications.")
            showLoading(false)
            return // Exit if the user is not signed in
        }

        // Remove the patientId filter to make medications universal
        val query: Query = database.orderByChild("createdAt") // You can use "createdAt" to get the most recent medications

        medicationListener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val medication = snapshot.getValue(Medication::class.java)
                medication?.let {
                    medications.add(it) // Add the new medication to the list
                    adapter.notifyItemInserted(medications.size - 1) // Notify adapter of new item
                }
                showEmptyState(medications.isEmpty())
                showLoading(false)
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                val updatedMedication = snapshot.getValue(Medication::class.java)
                updatedMedication?.let {
                    // Update the existing medication in the list
                    val index = medications.indexOfFirst { medication -> medication.id == it.id }
                    if (index != -1) {
                        medications[index] = it // Replace with updated medication
                        adapter.notifyItemChanged(index) // Notify adapter of update
                    }
                }
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
                val removedMedication = snapshot.getValue(Medication::class.java)
                removedMedication?.let {
                    val index = medications.indexOfFirst { medication -> medication.id == it.id }
                    if (index != -1) {
                        medications.removeAt(index) // Remove medication from list
                        adapter.notifyItemRemoved(index) // Notify adapter of removal
                    }
                }
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                // Handle child moved, if needed (this case may not apply)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("PatientMedicationsFragment", "Error fetching medications: ${error.message}")
                // Handle permission error or other failures
                if (error.code == DatabaseError.PERMISSION_DENIED) {
                    showError("You don't have permission to perform this operation.")
                } else {
                    showError("Failed to load medications. Please try again.")
                }
                showLoading(false)
            }
        }

        query.addChildEventListener(medicationListener!!) // Attach listener to Firebase
    }

    private fun setupRecyclerView() {
        adapter = MedicationAdapter(
            medications = medications,
            onApprovalRequest = { medication ->
                Toast.makeText(
                    requireContext(),
                    "Approval requested for ${medication.name}",
                    Toast.LENGTH_SHORT
                ).show()
                // Update database or notify doctor
            },
            onAddToCart = { medication ->
                if (medication.quantity > 0) {
                    cartViewModel.addToCart(medication.copy()) // Add to cart
                    Toast.makeText(
                        requireContext(),
                        "${medication.quantity} x ${medication.name} added to cart.",
                        Toast.LENGTH_SHORT
                    ).show()
                    medication.quantity = 0 // Reset quantity
                    adapter.notifyItemChanged(medications.indexOf(medication))
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Please select a quantity before adding to cart.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            isDoctor = false // For patients
        )

        binding.medicationsRecyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.medicationsRecyclerView.adapter = adapter
    }

    private fun showEmptyState(isEmpty: Boolean) {
        binding.emptyStateText.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.medicationsRecyclerView.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    private fun showLoading(show: Boolean) {
        binding.loadingSpinner.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun showError(message: String) {
        // Ensure the fragment is still attached to its activity/context before performing UI operations
        if (isAdded && context != null) {
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        } else {
            Log.e("PatientMedicationsFragment", "Fragment is not attached to context")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null

        // Clean up Firebase listener when the view is destroyed
        medicationListener?.let {
            database.removeEventListener(it)
        }
    }
}
