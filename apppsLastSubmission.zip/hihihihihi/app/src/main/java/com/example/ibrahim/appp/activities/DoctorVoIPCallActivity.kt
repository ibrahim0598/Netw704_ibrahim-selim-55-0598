package com.example.ibrahim.appp.activities

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ibrahim.appp.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import org.webrtc.*

class DoctorVoIPCallActivity : AppCompatActivity() {

    private lateinit var endCallButton: Button
    private lateinit var statusTextView: TextView

    private lateinit var peerConnectionFactory: PeerConnectionFactory
    private lateinit var peerConnection: PeerConnection
    private lateinit var audioTrack: AudioTrack
    private lateinit var database: FirebaseDatabase
    private lateinit var callRef: DatabaseReference

    private val auth: FirebaseAuth = FirebaseAuth.getInstance() // Firebase Auth
    private var callId: String = "call1" // Example call ID, adjust as needed

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voip_call)
        database = FirebaseDatabase.getInstance()

        endCallButton = findViewById(R.id.end_call_button)
        statusTextView = findViewById(R.id.status_text)

        // Check if the user is authenticated before proceeding
        val doctorId = auth.currentUser?.uid
        if (doctorId.isNullOrBlank()) {
            Log.e("DoctorVoIPCallActivity", "User is not authenticated.")
            statusTextView.text = "Please log in again."
            return
        }

        // Initialize WebRTC
        initializeWebRTC()

        // Listen for incoming offers from the patient (Firebase)
        listenForIncomingOffer()

        // Start listening for ICE candidates
        listenForIceCandidates()

        endCallButton.setOnClickListener {
            onEndCallButtonClick()
        }

        // Update status initially
        statusTextView.text = "Waiting for offer..."
    }

    private fun initializeWebRTC() {
        val options = PeerConnectionFactory.InitializationOptions.builder(this)
            .createInitializationOptions()
        PeerConnectionFactory.initialize(options)

        peerConnectionFactory = PeerConnectionFactory.builder().createPeerConnectionFactory()

        // Create AudioTrack for the doctor
        val audioSource = peerConnectionFactory.createAudioSource(MediaConstraints())
        audioTrack = peerConnectionFactory.createAudioTrack("audioTrack", audioSource)
    }

    private fun listenForIncomingOffer() {
        val doctorId = auth.currentUser?.uid
        if (doctorId.isNullOrBlank()) {
            Log.e("DoctorVoIPCallActivity", "User is not authenticated.")
            return
        }

        // Fetch call information from Firebase
        callRef = database.reference.child("calls").child(callId)

        callRef.child("offer").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val offerData = snapshot.value as? Map<String, String>
                if (offerData != null) {
                    val sdpDescription = offerData["sdp"]
                    if (sdpDescription != null) {
                        handleIncomingOffer(sdpDescription)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("DoctorVoIPCallActivity", "Error listening for offer: ${error.message}")
            }
        })
    }

    private fun handleIncomingOffer(sdpDescription: String) {
        statusTextView.text = "Offer received. Preparing to answer..."

        // Create RTC configuration and peer connection
        val rtcConfig = PeerConnection.RTCConfiguration(listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        ))
        rtcConfig.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        peerConnection = peerConnectionFactory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate?.let {
                    sendIceCandidate(candidate)
                }
            }
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onDataChannel(dataChannel: DataChannel?) {}
            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {}
            override fun onAddStream(mediaStream: MediaStream?) {
                // Audio track is added automatically to peer connection
            }
            override fun onRemoveStream(mediaStream: MediaStream?) {}
            override fun onRenegotiationNeeded() {}
        }) ?: return

        // Set the remote description from the offer
        val remoteSdp = SessionDescription(SessionDescription.Type.OFFER, sdpDescription)
        peerConnection.setRemoteDescription(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {}
            override fun onSetSuccess() {
                // After setting remote description, create the answer
                createAnswer()
            }
            override fun onCreateFailure(error: String?) {}
            override fun onSetFailure(error: String?) {}
        }, remoteSdp)
    }

    private fun createAnswer() {
        val sdpConstraints = MediaConstraints()
        peerConnection.createAnswer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                sdp?.let {
                    peerConnection.setLocalDescription(object : SdpObserver {
                        override fun onCreateSuccess(sdp: SessionDescription?) {}
                        override fun onSetSuccess() {
                            // Send the SDP answer back to the patient
                            sendAnswerToPatient(sdp)
                        }
                        override fun onCreateFailure(error: String?) {}
                        override fun onSetFailure(error: String?) {}
                    }, it)
                }
            }

            override fun onCreateFailure(error: String?) {
                Log.e("DoctorVoIPCallActivity", "Failed to create answer: $error")
            }

            override fun onSetSuccess() {}
            override fun onSetFailure(error: String?) {}
        }, sdpConstraints)
    }

    private fun sendAnswerToPatient(sdp: SessionDescription) {
        val answerData = mapOf(
            "sdp" to sdp.description,
            "type" to "answer",
            ("from" to auth.currentUser?.uid ?: "UnknownDoctor") as Pair<Any, Any>,  // Using Firebase Auth to get the current doctor's ID
            "to" to "PatientId"  // Replace with actual patient ID
        )
        callRef.child("answer").setValue(answerData)
    }

    private fun sendIceCandidate(candidate: IceCandidate) {
        val iceCandidateData = hashMapOf(
            "candidate" to candidate.sdp,
            "sdpMid" to candidate.sdpMid,
            "sdpMLineIndex" to candidate.sdpMLineIndex
        )
        callRef.child("candidates").push().setValue(iceCandidateData)
    }

    private fun listenForIceCandidates() {
        callRef.child("candidates").addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val candidateData = snapshot.value as? Map<String, String>
                candidateData?.let {
                    val sdp = it["candidate"]
                    val sdpMid = it["sdpMid"]
                    val sdpMLineIndex = it["sdpMLineIndex"]?.toIntOrNull()

                    if (sdp != null && sdpMid != null && sdpMLineIndex != null) {
                        val iceCandidate = IceCandidate(sdpMid, sdpMLineIndex, sdp)
                        peerConnection.addIceCandidate(iceCandidate)
                    }
                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun onEndCallButtonClick() {
        peerConnection.close()
        callRef.child("status").setValue("ended") // Update the call status in Firebase
        statusTextView.text = "Call Ended"
        endCallButton.visibility = View.GONE
    }

    override fun onDestroy() {
        super.onDestroy()
        peerConnectionFactory.dispose() // Clean up WebRTC resources
    }
}
