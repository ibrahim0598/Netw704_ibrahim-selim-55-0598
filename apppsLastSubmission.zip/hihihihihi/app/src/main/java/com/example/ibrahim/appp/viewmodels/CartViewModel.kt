package com.example.ibrahim.appp.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.ibrahim.appp.models.Medication

class CartViewModel : ViewModel() {

    private val _cartItems = MutableLiveData<MutableList<Medication>>(mutableListOf())
    val cartItems: LiveData<MutableList<Medication>> get() = _cartItems

    private val _totalPrice = MutableLiveData(0.0)
    val totalPrice: LiveData<Double> get() = _totalPrice

    // Add a medication to the cart
    fun addToCart(medication: Medication) {
        val currentCart = _cartItems.value ?: mutableListOf()

        // Check if the item already exists in the cart
        val existingItem = currentCart.find { it.id == medication.id }
        if (existingItem != null) {
            // Update quantity if the medication is already in the cart
            existingItem.quantity += medication.quantity
        } else {
            // Add a new item to the cart
            currentCart.add(medication)
        }

        _cartItems.value = currentCart // Re-assign to MutableLiveData
        calculateTotalPrice() // Recalculate total price
    }

    // Update the quantity of a medication in the cart
    fun updateMedicationQuantity(id: String, newQuantity: Int) {
        val currentCart = _cartItems.value ?: return

        val medication = currentCart.find { it.id == id }
        if (medication != null) {
            if (newQuantity > 0) {
                medication.quantity = newQuantity
            } else {
                // Remove item if quantity is zero or less
                currentCart.remove(medication)
            }
            _cartItems.value = currentCart // Re-assign to MutableLiveData
            calculateTotalPrice() // Recalculate total price
        }
    }

    // Remove a medication from the cart
    fun removeFromCart(medication: Medication) {
        val currentCart = _cartItems.value ?: mutableListOf()
        currentCart.remove(medication)
        _cartItems.value = currentCart // Re-assign to MutableLiveData
        calculateTotalPrice() // Recalculate total price
    }

    // Clear all items from the cart
    fun clearCart() {
        _cartItems.value = mutableListOf() // Reset cart
        _totalPrice.value = 0.0 // Reset total price
    }

    // Calculate the total price of items in the cart
    private fun calculateTotalPrice() {
        val total = _cartItems.value?.sumOf { it.price * it.quantity } ?: 0.0
        _totalPrice.value = total
    }

    // Function to handle medication approval
    fun approveMedication(medicationId: String) {
        val currentCart = _cartItems.value ?: mutableListOf()

        // Find medication by ID and update approval status
        val medication = currentCart.find { it.id == medicationId }
        medication?.let {
            it.isApproved = true
            _cartItems.value = currentCart // Re-assign to MutableLiveData
            calculateTotalPrice() // Recalculate total price after approval
        }
    }

    // Function to remove all unapproved medications
    fun removeUnapprovedMedications() {
        val currentCart = _cartItems.value?.filter { it.isApproved }?.toMutableList() ?: mutableListOf()

        // Update cart and recalculate total price after removing unapproved items
        _cartItems.value = currentCart
        calculateTotalPrice() // Recalculate total price
        }
}
